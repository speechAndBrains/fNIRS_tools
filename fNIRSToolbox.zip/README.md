# fNIRS_tools
Scripts for MVPA of fNIRS
